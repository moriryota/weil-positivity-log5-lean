"""0606 (Claude): frozen-environment exports and the Lean FRO comparator for rh0605; adapted from GPT 0583."""
from pathlib import Path
import json,subprocess,time,hashlib,os,sys
B=Path('/home/rhcheck/palomar0389/rh0605');E=B/'evidence';R=E/'final-001';R.mkdir(exist_ok=False)
L=Path('/opt/rh-audit0528-tools/lean-4.34.0-linux/bin');T=Path('/opt/rh-audit0528-tools/comparator')
ENV=json.loads((E/'final_environments.json').read_text())
TARGETS=json.loads((E/'FINAL_EXPORT_TARGETS.json').read_text())['ordered_export_targets']
state={'status':'PREPARING','scope':'Lean FRO comparator for release candidate 0605 (both theorems); not registry/Palomar registration','started':time.time()}
def save():
 p=R/'status.tmp';p.write_text(json.dumps(state,indent=2));p.replace(R/'status.json')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for s in iter(lambda:f.read(1048576),b''):h.update(s)
 return h.hexdigest()
def inputs():
 files=[]
 for project in ['trusted','candidate']:
  root=B/project
  files += [p for p in root.rglob('*') if p.is_file()]
 files += [Path(ENV['candidate'][k]) for k in ['COMPARATOR_LANDRUN','COMPARATOR_LEAN4EXPORT','COMPARATOR_NANODA']]
 files += [T/'.lake/build/bin/comparator',L/'lean',L/'lake',R/'config.json',E/'final_environments.json',E/'FINAL_EXPORT_TARGETS.json',E/'ready_gate.json',E/'run_final_vm.py']
 # Hash all actual resolver inputs, including upstream olean/IR, plus all source/config/tool paths from protection preflight.
 for root in set(ENV['trusted']['LEAN_PATH'].split(':')+ENV['candidate']['LEAN_PATH'].split(':')):
  p=Path(root)
  if p.exists(): files += [f for f in p.rglob('*') if f.is_file()]
 files += [Path(k) for k in json.loads((E/'source_config_tool_hashes.json').read_text())]
 files=list(set(files))
 return {str(p):sha(p) for p in files}
def run(n,cmd,label,limit=0,export=False):
 req=dict(cwd=str(B/n),command=list(map(str,cmd)),environment=ENV[n],timeout=limit,trusted_cache_network=False)
 (R/(label+'.request.json')).write_text(json.dumps(req,indent=2));state.update(status='RUNNING',phase=label);save()
 t=time.time()
 with (R/(label+'.stdout')).open('w') as out,(R/(label+'.stderr')).open('w') as err:
  try:
   p=subprocess.run(['sudo','-n','-u','rhcheck','sudo','-n','/usr/local/libexec/rh-audit0605-launch',json.dumps(req)],stdout=out,stderr=err,timeout=None if limit==0 else limit+90)
  except subprocess.TimeoutExpired:
   (R/(label+'.result.json')).write_text(json.dumps(dict(started=t,ended=time.time(),exit_code=None,reason='supervisor_timeout')))
   raise
 (R/(label+'.result.json')).write_text(json.dumps(dict(started=t,ended=time.time(),exit_code=p.returncode)))
 state.update(status='POSTPROCESSING',phase=label,child_exit_code=p.returncode);save()
 if p.returncode:raise RuntimeError(label+' exit '+str(p.returncode))
 return R/(label+'.stdout')
before=None
try:
 gate=json.loads((E/'ready_gate.json').read_text())
 if gate['status']!='READY_FOR_REVIEW_NOT_AUDIT_PASS':raise RuntimeError('missing ready gate')
 for name,expected in gate['files'].items():
  if sha(E/name)!=expected:raise RuntimeError('preflight evidence changed '+name)
 binding=json.loads((E/'execution_binding.json').read_text())
 for name,expected in binding.items():
  if sha(E/name)!=expected:raise RuntimeError('execution binding mismatch '+name)
 for path,expected in json.loads((E/'source_config_tool_hashes.json').read_text()).items():
  if sha(Path(path))!=expected:raise RuntimeError('source/config/tool changed '+path)
 for path,expected in json.loads((E/'full_protection.json').read_text())['metadata'].items():
  p=Path(path);s=p.stat()
  actual={'uid':s.st_uid,'gid':s.st_gid,'mode':oct(s.st_mode&0o7777),'acl':any('posix_acl' in k for k in os.listxattr(p))}
  if actual!=expected:raise RuntimeError('protection metadata changed '+path)
 for n in ['Challenge','Solution']:
  if json.loads((E/(n+'.readonly.status.json')).read_text())['exit_code']!=0:raise RuntimeError('readonly reuse not verified')
 config={'challenge_module':'Challenge','solution_module':'Solution','theorem_names':['RHLog5Release.target_log5','RHLog5Release.target_log5_uniform'],'definition_names':[],'permitted_axioms':['propext','Quot.sound','Classical.choice'],'enable_nanoda':True}
 (R/'config.json').write_text(json.dumps(config,indent=2));(R/'config.json').chmod(0o444)
 before=inputs();(R/'inputs.before.json').write_text(json.dumps(before,indent=2))
 exports=[]
 for n in ['trusted','candidate']:
  cmd=['/usr/local/bin/landrun','--best-effort','--ro','/','--rw','/dev','-ldd','-add-exec','--env','PATH','--env','HOME','--env','LEAN_PATH','--env','LEAN_ABORT_ON_PANIC','--rox',str(L.parent),'--',ENV[n]['COMPARATOR_LEAN4EXPORT'],'Challenge','--',*TARGETS]
  exports.append(run(n,cmd,n+'-challenge-export',0,True))
 match={'trusted_sha256':sha(exports[0]),'candidate_sha256':sha(exports[1])}
 match['identical']=match['trusted_sha256']==match['candidate_sha256'];(R/'challenge-export-comparison.json').write_text(json.dumps(match,indent=2))
 if not match['identical']:raise RuntimeError('challenge exports differ')
 out=run('candidate',[T/'.lake/build/bin/comparator',R/'config.json'],'comparator',0)
 # Small completion tail only, preserve full raw export/comparator outputs on disk.
 with out.open('rb') as f:f.seek(max(0,out.stat().st_size-65536));tail=f.read().decode(errors='replace')
 markers=['nanoda kernel accepts the solution','Lean default kernel accepts the solution','Your solution is okay!']
 if not all(m in tail for m in markers):raise RuntimeError('success markers absent')
 after=inputs();(R/'inputs.after.json').write_text(json.dumps(after,indent=2))
 if before!=after:raise RuntimeError('input bytes changed')
 state.update(status='COMPARATOR_ACCEPTED_REVIEW_REQUIRED',inputs_unchanged=True)
except BaseException as e:
 state.update(status='POSTCHECK_AFTER_FAILURE',error=repr(e));save()
finally:
 if before is not None and not (R/'inputs.after.json').exists():
  try:
   after=inputs();(R/'inputs.after.json').write_text(json.dumps(after,indent=2));state['inputs_unchanged']=before==after
  except BaseException as e:state['postcheck_error']=repr(e)
 if state['status']!='COMPARATOR_ACCEPTED_REVIEW_REQUIRED':state['status']='FAILED'
 state['ended']=time.time();save();os.sync()
print(json.dumps(state),flush=True)

sys.exit(0 if state['status']=='COMPARATOR_ACCEPTED_REVIEW_REQUIRED' else 1)
